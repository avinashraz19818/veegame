RaxiWin final display/result alignment patch
============================================
Replace:
assets/js/useLottery.hook-_2rEnQ4S.js
assets/js/useWinGo3-5zV6kUzs.js
api/Lottery/index.php
api-live-v4/index.php

This is display-only: top period is shown one period behind, history labels are
aligned, and each visible result number/color/Big-Small is moved one row back.
Canonical bet issue and database settlement remain unchanged. Clear browser
cache and PHP OPcache after replacing. Do not copy ShreeWin bootstrap files.
