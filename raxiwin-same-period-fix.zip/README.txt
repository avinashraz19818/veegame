RaxiWin same-period display fix
================================
Replace only the two matching files:
assets/js/useLottery.hook-_2rEnQ4S.js
assets/js/useWinGo3-5zV6kUzs.js

The top display is one completed period behind. History/API result rows are
left untouched, so the displayed period matches the result row supplied by the
API. Bet submission still uses the canonical provider issue. Do not replace
API or bootstrap files. Clear browser cache after replacing.
