RaxiWin original API restore
============================

Replace these files to undo the incompatible period patch:
  api/Lottery/index.php
  api-live-v4/index.php

These are the original files from avinashraz19818/raxiwin main branch.
Do not replace bootstrap files with ShreeWin files.
