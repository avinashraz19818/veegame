RaxiWin final same-period result alignment
==========================================
Replace only:
assets/js/useLottery.hook-_2rEnQ4S.js
assets/js/useWinGo3-5zV6kUzs.js

The top display is one period behind. History/result rows keep their period
labels and the displayed Number/Color/Big-Small data is moved to the matching
period row. Bets still submit canonical provider issue. No PHP/API/bootstrap
files are changed. Clear browser/PWA cache after replacement.
