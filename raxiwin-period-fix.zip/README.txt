RaxiWin one-period display alignment
====================================

Replace these files in the RaxiWin installation:
  draw-live-v4/index.php
  saas_lottery/bootstrap.php
  saas_lottery/bootstrap_live_v3.php
  saas_lottery/bootstrap_live_v4.php

Only draw-live-v4/index.php contains the new change. The three bootstrap files
are included as the matching original RaxiWin files and must not be replaced
with ShreeWin versions.

The change shifts only the public WinGo history/result period label back by one
period. The canonical database issue number, bet lookup, result and settlement
are not changed.
