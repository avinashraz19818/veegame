RaxiWin one-period result alignment patch
=========================================

The screenshot uses the /Lottery/GetHistoryIssuePage API. Replace these files:

  api/Lottery/index.php
  api-live-v4/index.php

The provider history is one completed round behind the visible clock. This
patch advances only the public WinGo history label by one period, so when the
current round is 11382 the latest completed result is shown as 11381.
Result value/premium and database settlement IDs are not changed.

Do not copy ShreeWin bootstrap files over RaxiWin.
