<?php
require_once dirname(__DIR__, 2) . '/saas_lottery/bootstrap.php';

$action = isset($_GET['action']) ? preg_replace('/[^A-Za-z0-9_-]/', '', (string) $_GET['action']) : '';
$input = sl_input();

\n/** Display-only alignment: provider history is one completed round late.\n * Canonical DB issue IDs and settlement are intentionally untouched.\n */\nfunction raxiwin_display_previous_periods($gameCode, $list)\n{\n    if (!is_array($list) || !$list || strpos((string)$gameCode, 'WinGo_') !== 0) return $list;\n    $interval = sl_interval_seconds($gameCode);\n    foreach ($list as &$item) {\n        $issue = isset($item['issueNumber']) ? (string)$item['issueNumber'] : '';\n        if (!preg_match('/^(\\d{8})\\d{9}$/', $issue)) continue;\n        $date = substr($issue, 0, 4) . '-' . substr($issue, 4, 2) . '-' . substr($issue, 6, 2);\n        $sequence = (int)substr($issue, -4);\n        $dayStart = strtotime($date . ' 00:00:00 UTC');\n        if ($dayStart === false || $sequence < 1) continue;\n        $start = $dayStart + (($sequence - 1) * $interval) + $interval;\n        $item['issueNumber'] = sl_issue_number_for_start($gameCode, $start);\n    }\n    unset($item);\n    return $list;\n}\n
try {
    sl_install_schema();

    switch ($action) {
        // Public actions (no user session required)
        case 'GetGameList':
            sl_ok(sl_game_list());
            break;

        case 'GetGameInfo':
            $gameCode = sl_game_code($input);
            sl_ok(sl_game_info($gameCode));
            break;

        case 'GetHistoryIssuePage':
            $gameCode = sl_game_code($input);
            $history = sl_history_page($gameCode, $input);
            if (is_array($history) && isset($history['list'])) {
                $history['list'] = raxiwin_display_previous_periods($gameCode, $history['list']);
            }
            sl_ok($history);
            break;

        case 'GetTrendStatistics':
            $gameCode = sl_game_code($input);
            sl_ok(sl_trend($gameCode));
            break;

        case 'GetBetLimit':
            $gameCode = sl_game_code($input);
            sl_ok(sl_bet_limits($gameCode));
            break;

        case 'GetGameIntroduce':
            $gameCode = sl_game_code($input);
            sl_ok(sl_game_introduce($gameCode));
            break;

        case 'GetDragonList':
        case 'GetFollowPlanList':
        case 'GetHistoryFollowRecordPageList':
            sl_ok(array('list' => array(), 'pageNo' => 1, 'totalPage' => 0, 'totalCount' => 0));
            break;

        case 'GetFollowRule':
        case 'GetFollowRecord':
            sl_ok(null);
            break;

        case 'AddFollowRecord':
        case 'StopFollowRecord':
            sl_fail(405, 'Follow betting is not enabled for these games', 405, 200);
            break;

        case 'VideoWinGoBet':
            sl_fail(405, 'This lottery family is not enabled', 405, 200);
            break;

        // Authenticated actions (user session required)
        case 'GetUserInfo':
            $user = sl_require_user();
            sl_ok(array(
                'userId' => (int) $user['id'],
                'tenantId' => 1,
                'agentCode' => 'LOCAL',
                'sysCurrency' => 'INR',
                'state' => 1,
                'tenantAccount' => (string) $user['id'],
                'isOpenFollow' => false,
                'skin' => 'blackGoldStyle',
                'skinColor' => '#d7ad55'
            ));
            break;

        case 'GetBalance':
            $user = sl_require_user();
            sl_ok(array('balance' => sl_wallet_balance((int) $user['id'])));
            break;

        case 'WinGoBet':
        case 'TrxWinGoBet':
        case 'K3Bet':
        case 'D5Bet':
        case 'MotoRaceBet':
            $user = sl_require_user();
            sl_ok(sl_place_bet($user, $input));
            break;

        case 'GetRecordPage':
            $user = sl_require_user();
            sl_ok(sl_record_page((int) $user['id'], $input));
            break;

        case 'GetWinLossResult':
            $user = sl_require_user();
            sl_ok(sl_win_loss((int) $user['id'], $input));
            break;

        default:
            sl_fail(404, 'Unknown lottery action', 404, 404);
    }
} catch (Throwable $e) {
    error_log('[saas-lottery] ' . $e->getMessage());
    sl_fail(500, 'Lottery service is temporarily unavailable', 500, 500);
}
