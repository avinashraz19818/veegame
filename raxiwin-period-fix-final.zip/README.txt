RaxiWin coordinated period alignment patch
============================================
Replace these files, preserving directories:
assets/js/useLottery.hook-_2rEnQ4S.js
assets/js/useWinGo3-5zV6kUzs.js
api/Lottery/index.php
api-live-v4/index.php

The top screen displays the previous period. Bets still submit the canonical
provider issue, so betting and settlement remain aligned. Public WinGo history
labels are advanced to match the displayed previous period. Do not copy ShreeWin
bootstrap files. Clear browser cache and PHP OPcache after replacing.
