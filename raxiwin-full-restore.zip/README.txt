RaxiWin original restore for the four files used by the period patch.
Replace the four files preserving directories, then clear PHP OPcache and browser site data.
